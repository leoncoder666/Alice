# Hanya kamus

# Kamus dari dia
sapa = ["hai", "halo", "pagi", "pagi juga", "siang", "siang juga", "sore", "sore juga", "malam", "malam juga", "woy", "oi"]
sapa2 = ["hai alice", "halo alice"]
sapa_gombal = ["hai sayang", "halo sayang", "hai beb", "hai sayangku", "hai cinta", "halo cinta"]
tanya_nama = ["nama km siapa", "nama km siapa?", "nama kamu siapa", "nama kamu siapa?", "nama kam siapa", "nama kam siapa?", "nama mu siapa", "nama mu siapa?", "nama lu siapa" "nama lu siapa?", "siapa nama km", "siapa nama km?", "siapa naa kamu", "siapa nama kamu?", "nama kamu apa", "nama kamu apa?", "nama km siapa ya?"]
nembak = ["mau ga jadi pacar aku", "mau gak jadi pacar aku?", "mau ga jadi pacar ku", "mau ga jadi pacar ku?", "mau jadi pacar ku ga", "mau jadi pacar ku ga?", "mau jadi pacar ku gak", "mau jadi pacar ku gak?", "mau jadi pacarku ga", "mau jadi pacarku ga?", "mau jadi pacarku gak", "mau jadi pacarku gak?", "mau ga jadi pacar aku?", "mau ga pacaran sama aku?", "mau ga jadi pacarku?", "mau gak jadi pacarku?", "mau jadi pacar ku ga", "mau jadi pacar ku ga?", "mau jadi pacar ku gak", "mau jadi pacar ku gak?", "mau jadi pacarku ga", "mau jadi pacarku ga?", "mau jadi pacar ku gak", "mau jadi pacarku gak?", "km mau jadi pacar aku ga", "km mau jadi pacar aku ga?", "km mau jadi pacar ku ga", "km mau jadi pacar ku ga?", "km mau jadi pacarku ga", "km mau jadi pacarku ga?", "km mau jadi pacarku gak", "km mau jadi pacarku gak?"]
nembak2 = ["jadian kuy", "jadian kuy?", "pacaran yuk", "pacaran yuk?", "jadian ayok"]
tanya_alamat = ["tinggal dimana", "tinggal dimana?", "km tinggal dimana", "km tinggal dimana?", "kamu tinggal dimana", "kamu tinggal dimana?", "dimana kamu tinggal", "dimana kamu tinggal?", "kamu dimana tinggal?"]
tanya_kondisi = ["lagi ngapain", "lagi ngapain?", "kamu lagi ngapain", "kamu lagi ngapain?", "lagi ngapain kamu", "lagi ngapain kamu?", "lagi ngapain kamu sekarang?"]
tanya_sama_siapa = ["sama siapa", "siapa siapa?", "dengan siapa", "dengan siapa?"]
kasar = ["anjing", "asw", "asu", "ashu", "babi", "monyet", "kontol", "kntl", "memek", "mmk", "memex", "bujang", "bangsat", "bajingan", "brengsek", "berengsek"]


# Kamus dari BOT
cinta = ["sayang", "pak", "beb", "pangeranku", "sayangku", "cintaku"]
jawab_sapa = ["iya", "halo juga", "hai juga", "mmmm", "paan"]
jawab_sapa_gombal = ["iya sayang", "hai juga sayang", "halo juga sayang", "iya beb", "kenapa sayang?"]
jawab_dia_nembak = ["mau deh hehe", "mau kok kwkwkwk", "mau lah hahaha", "kamu langsung nembak, mau kok hehe", "mau kok sayang"]
jawab_dia_nembak2 = ["yahaha hayuk", "kuy lah sayang", "kuy lah sayang wkwkw", "wkwkwkw hayuk"]
ga_ngerti = ["ga ngerti aku", "Alice ga ngerti ahk", "gapaham ihk", "ga ngerti ihk", "gapaham:("]
jawab_tanya_alamat = ["di hati kamu wkwkwk", "di hati kamu lah", "di neraka jalan tol nomor 3 dari kanan simpang perempat", "di hati pria yang sayang tampan, yaitu kamu", "di hati kamu lah sayang"]
jawab_kondisi = ["lagi ngombrol dengan orang ganteng hehe", "lagi duduk aja di hati km"]
jawab_sama_siapa = ["sendiri", "sendiri aja nih"]
jawab_kasar = ["jangan kasar dong:(", "jangan kasar lah:(", "jangan ngegas dong:(", "yah kamu kasar:("]
